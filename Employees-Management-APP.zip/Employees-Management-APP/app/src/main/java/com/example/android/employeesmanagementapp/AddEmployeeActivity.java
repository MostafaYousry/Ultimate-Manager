package com.example.android.employeesmanagementapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class AddEmployeeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_employee);
    }
}
