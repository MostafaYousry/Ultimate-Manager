package com.example.android.employeesmanagementapp;

/**
 * interface to handle click events
 */
public interface RecyclerViewItemClickListener {
    void onItemClick(int clickedItemIndex);
}
