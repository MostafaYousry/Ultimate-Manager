package com.example.android.employeesmanagementapp.data.daos;

import androidx.room.Dao;

@Dao
public interface EmployeesTasksDao {


}
